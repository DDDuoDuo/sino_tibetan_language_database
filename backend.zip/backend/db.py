import os
import pymysql
from dotenv import load_dotenv

load_dotenv()

def get_connection():
    return pymysql.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "3306")),
        user=os.getenv("DB_USER", "debian-sys-maint"),
        password=os.getenv("DB_PASS", "OtpLYP2RE9IUk6b0"),
        database=os.getenv("DB_NAME", "language_map"),
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=False
    )
