from flask import Blueprint, request, jsonify
from models.languages import replace_project_languages, get_project_languages

languages_bp = Blueprint("languages", __name__)

@languages_bp.get("/projects/<project_id>/languages")
def list_languages(project_id):
    langs = get_project_languages(project_id)
    return jsonify(langs)

@languages_bp.post("/projects/<project_id>/languages")
def save_languages(project_id):
    data = request.get_json(force=True)
    replace_project_languages(project_id, data or [])
    return jsonify({"success": True})
