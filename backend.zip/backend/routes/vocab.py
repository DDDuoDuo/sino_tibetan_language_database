from flask import Blueprint, request, jsonify
from models.vocab import replace_project_vocab, get_project_vocab

vocab_bp = Blueprint("vocab", __name__)

@vocab_bp.get("/projects/<project_id>/vocab")
def list_vocab(project_id):
    items = get_project_vocab(project_id)
    return jsonify(items)

@vocab_bp.post("/projects/<project_id>/vocab")
def save_vocab(project_id):
    data = request.get_json(force=True)
    replace_project_vocab(project_id, data or [])
    return jsonify({"success": True})
