from db import get_connection
from typing import Optional, Dict

def upsert_project_tree_file(project_id: str, tree_file: Optional[Dict]) -> None:
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                "DELETE FROM project_tree_files WHERE project_id=%s",
                (project_id,)
            )

            if not tree_file:
                cursor.execute(
                    "UPDATE projects SET has_treefile=0 WHERE id=%s",
                    (project_id,)
                )
                conn.commit()
                return

            file_name = tree_file.get("name")
            mime_type = tree_file.get("type")
            content = tree_file.get("content")

            sql = """
                INSERT INTO project_tree_files
                (project_id, file_name, mime_type, content, updated_at)
                VALUES (%s,%s,%s,%s,NOW())
            """
            cursor.execute(sql, (
                project_id,
                file_name,
                mime_type,
                content,
            ))

            cursor.execute(
                "UPDATE projects SET has_treefile=1 WHERE id=%s",
                (project_id,)
            )

        conn.commit()
    finally:
        conn.close()

def get_project_tree_file(project_id):
    conn = get_connection()
    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT project_id, file_name, mime_type, content, updated_at
            FROM project_tree_files
            WHERE project_id = %s
            LIMIT 1
        """, (project_id,))
        row = cursor.fetchone()
    conn.close()
    return row
