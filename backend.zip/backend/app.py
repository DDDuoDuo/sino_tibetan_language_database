from flask import Flask
from flask_cors import CORS

from routes.auth import auth_bp
from routes.projects import projects_bp
from routes.vocab import vocab_bp
from routes.languages import languages_bp

def create_app():
    app = Flask(__name__)
    CORS(app)

    app.secret_key = "82379971e2e8daff7588d0b6a42b1ed816fe4916c3f8fede9f51d44932419081"

    app.register_blueprint(auth_bp, url_prefix="/api")
    app.register_blueprint(projects_bp, url_prefix="/api")
    app.register_blueprint(vocab_bp, url_prefix="/api")
    app.register_blueprint(languages_bp, url_prefix="/api")

    @app.get("/api/health")
    def health():
        return {"status": "ok"}

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, port=3000)
